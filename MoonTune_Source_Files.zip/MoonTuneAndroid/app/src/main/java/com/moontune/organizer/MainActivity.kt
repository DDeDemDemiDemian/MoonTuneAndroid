package com.moontune.organizer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.documentfile.provider.DocumentFile
import androidx.core.view.setPadding
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import org.jaudiotagger.audio.AudioFileIO
import org.jaudiotagger.tag.FieldKey
import com.github.QuickLyric.fpcalc.FpCalc

/**
 * MoonTune starter app. It deliberately requires user-selected folders through SAF.
 * Never reorganizes files automatically: every destructive operation requires review.
 */
class MainActivity : Activity() {
    private val pickFolderRequest = 2001
    private var rootUri: Uri? = null
    private var root: DocumentFile? = null
    private val audioFiles = mutableListOf<DocumentFile>()
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var apiKeyInput: EditText
    private lateinit var languageInput: EditText
    private lateinit var list: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private val rows = mutableListOf<String>()
    private val extensions = setOf("mp3", "m4a", "mp4", "flac", "ogg", "opus", "wav", "aiff", "wma", "aif")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20); setBackgroundColor(0xFFF7F5FC.toInt()) }
        val title = TextView(this).apply { text = "MoonTune"; textSize = 30f; setTextColor(0xFF30254B.toInt()); gravity = Gravity.CENTER_VERTICAL }
        val subtitle = TextView(this).apply { text = "Music library • identify • tag • organize"; textSize = 14f; setTextColor(0xFF625B71.toInt()) }
        apiKeyInput = EditText(this).apply { hint = "Your AcoustID application API key"; singleLine = true }
        languageInput = EditText(this).apply { hint = "Language (manual / from lyrics; e.g. English)"; singleLine = true }
        status = TextView(this).apply { text = "Choose a music folder on internal storage or USB. Files are not changed during scanning."; textSize = 14f; setPadding(0, 12, 0, 12) }
        list = ListView(this)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, rows)
        list.adapter = adapter
        list.setOnItemClickListener { _, _, position, _ -> if (position in audioFiles.indices) showEditDialog(audioFiles[position]) }
        layout.addView(title); layout.addView(subtitle)
        layout.addView(button("Choose music folder") { pickFolder() })
        layout.addView(apiKeyInput)
        layout.addView(button("Scan selected folder") { scanFolder() })
        layout.addView(button("Identify unknown tracks (fingerprint lookup)") { identifyUnknownTracks() })
        layout.addView(button("Tag / organize selected track") { val p = list.checkedItemPosition; if (p >= 0 && p < audioFiles.size) showEditDialog(audioFiles[p]) else Toast.makeText(this, "Tap a track below first", Toast.LENGTH_SHORT).show() })
        layout.addView(languageInput)
        layout.addView(status)
        layout.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(layout)
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply { text = label; setOnClickListener { action() } }

    private fun pickFolder() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(intent, pickFolderRequest)
    }

    @Deprecated("Use of startActivityForResult retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickFolderRequest && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            contentResolver.takePersistableUriPermission(uri, flags)
            rootUri = uri; root = DocumentFile.fromTreeUri(this, uri)
            status.text = "Folder selected. Scan it to build the catalog."
        }
    }

    private fun scanFolder() {
        val folder = root ?: run { toast("Choose a folder first"); return }
        status.text = "Scanning…"
        executor.execute {
            val found = mutableListOf<DocumentFile>()
            fun walk(dir: DocumentFile) {
                dir.listFiles().forEach { item ->
                    if (item.isDirectory) walk(item)
                    else if (item.name?.substringAfterLast('.', "")?.lowercase() in extensions) found.add(item)
                }
            }
            try { walk(folder) } catch (_: Exception) { }
            runOnUiThread {
                audioFiles.clear(); audioFiles.addAll(found)
                rows.clear(); rows.addAll(found.map { "${it.name ?: "(unnamed)"}\n${it.type ?: "audio"} • ${formatBytes(it.length())}" })
                adapter.notifyDataSetChanged()
                status.text = "Found ${found.size} audio files. Tap a row to edit tags."
            }
        }
    }

    private fun identifyUnknownTracks() {
        val key = apiKeyInput.text.toString().trim()
        if (key.isBlank()) { toast("Enter your AcoustID application key first"); return }
        if (audioFiles.isEmpty()) { toast("Scan a folder first"); return }
        status.text = "Fingerprinting ${audioFiles.size} tracks. Keep the app open; this may take a long time for large libraries."
        executor.execute {
            var matched = 0; var failed = 0
            audioFiles.forEachIndexed { index, doc ->
                try {
                    val temp = File(cacheDir, "fp_${System.nanoTime()}_${safeName(doc.name ?: "track")}")
                    contentResolver.openInputStream(doc.uri)?.use { input -> temp.outputStream().use { output -> input.copyTo(output) } } ?: throw Exception("Can't read file")
                    val raw = FpCalc.fpCalc(arrayOf("-length", "120", temp.absolutePath))
                    val duration = Regex("DURATION=(\\d+)").find(raw)?.groupValues?.get(1) ?: Regex("duration[=: ]+(\\d+)", RegexOption.IGNORE_CASE).find(raw)?.groupValues?.get(1)
                    val fp = Regex("FINGERPRINT=([^\\r\\n]+)").find(raw)?.groupValues?.get(1) ?: Regex("fingerprint[=: ]+([^\\r\\n]+)", RegexOption.IGNORE_CASE).find(raw)?.groupValues?.get(1)
                    if (duration != null && fp != null) {
                        val response = acoustIdLookup(key, duration, fp)
                        val results = response.optJSONArray("results")
                        if (results != null && results.length() > 0) {
                            val top = results.getJSONObject(0)
                            val score = top.optDouble("score", 0.0)
                            val recordingId = top.optJSONArray("recordings")?.optJSONObject(0)?.optString("id")
                            if (recordingId != null && recordingId != "null" && score >= 0.75) {
                                val meta = musicBrainzRecording(recordingId)
                                if (meta != null) {
                                    val title = meta.optString("title", "")
                                    val artist = meta.optJSONArray("artist-credit")?.optJSONObject(0)?.optJSONObject("artist")?.optString("name", "") ?: ""
                                    runOnUiThread { status.text = "Match ${index + 1}/${audioFiles.size}: ${doc.name} → $artist — $title (${(score * 100).toInt()}%)" }
                                    // Do not auto-write metadata; user reviews each candidate first.
                                    doc.uri.toString()
                                    matched++
                                }
                            }
                        }
                    }
                    temp.delete()
                } catch (_: Exception) { failed++ }
                // AcoustID limit is 3 req/s; MusicBrainz requires <=1 request/s.
                try { TimeUnit.MILLISECONDS.sleep(1100) } catch (_: InterruptedException) { }
            }
            runOnUiThread { status.text = "Fingerprint pass finished. Strong matches found: $matched. Errors/unmatched: $failed. Review and tag files individually; no files were moved." }
        }
    }

    private fun acoustIdLookup(key: String, duration: String, fingerprint: String): JSONObject {
        val query = "client=${enc(key)}&duration=${enc(duration)}&fingerprint=${enc(fingerprint)}&meta=recordings&format=json"
        val conn = URL("https://api.acoustid.org/v2/lookup?$query").openConnection() as HttpURLConnection
        conn.connectTimeout = 15000; conn.readTimeout = 20000
        return conn.inputStream.bufferedReader().use { JSONObject(it.readText()) }.also { conn.disconnect() }
    }

    private fun musicBrainzRecording(id: String): JSONObject? {
        val conn = URL("https://musicbrainz.org/ws/2/recording/${enc(id)}?fmt=json&inc=artists+releases").openConnection() as HttpURLConnection
        conn.setRequestProperty("User-Agent", "MoonTuneOrganizer/0.1 (Android music library organizer)")
        conn.connectTimeout = 15000; conn.readTimeout = 20000
        return try { conn.inputStream.bufferedReader().use { JSONObject(it.readText()) } } finally { conn.disconnect() }
    }

    private fun showEditDialog(doc: DocumentFile) {
        val fields = listOf("Title", "Artist", "Album", "Year", "Genre", "Language")
        val inputs = fields.map { field -> EditText(this).apply { hint = field; singleLine = true } }
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24) }
        inputs.forEach { container.addView(it) }
        val language = languageInput.text.toString().trim()
        if (language.isNotEmpty()) inputs[5].setText(language)
        val dialog = android.app.AlertDialog.Builder(this).setTitle("Edit tags: ${doc.name}").setView(container)
            .setPositiveButton("Write tags to file") { _, _ ->
                val values = inputs.map { it.text.toString().trim() }
                executor.execute {
                    try {
                        val temp = File(cacheDir, "tag_${System.nanoTime()}_${safeName(doc.name ?: "track")}")
                        contentResolver.openInputStream(doc.uri)?.use { i -> temp.outputStream().use { o -> i.copyTo(o) } } ?: throw Exception("Read failed")
                        val audio = AudioFileIO.read(temp)
                        val tag = audio.tagOrCreateAndSetDefault
                        val keys = listOf(FieldKey.TITLE, FieldKey.ARTIST, FieldKey.ALBUM, FieldKey.YEAR, FieldKey.GENRE, FieldKey.LANGUAGE)
                        keys.forEachIndexed { i, key -> if (values[i].isNotBlank()) tag.setField(key, values[i]) }
                        audio.commit()
                        // SAF providers vary. Preserve the original until a complete replacement is available.
                        val replacement = DocumentFile.fromTreeUri(this, rootUri!!)?.createFile(doc.type ?: "audio/mpeg", "${doc.name}.moontune-new")
                            ?: throw Exception("Could not create safe replacement file")
                        contentResolver.openInputStream(Uri.fromFile(temp))?.close()
                        temp.inputStream().use { input -> contentResolver.openOutputStream(replacement.uri, "w")?.use { output -> input.copyTo(output) } ?: throw Exception("Write failed") }
                        runOnUiThread { status.text = "Tagged copy saved as ${replacement.name}. Original preserved. Verify it before replacing the original." }
                        temp.delete()
                    } catch (e: Exception) { runOnUiThread { status.text = "Tag write failed: ${e.message ?: "unsupported format or provider"}" } }
                }
            }.setNegativeButton("Cancel", null).create()
        dialog.show()
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun safeName(s: String) = s.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80)
    private fun formatBytes(n: Long): String = when { n < 1024 -> "$n B"; n < 1024*1024 -> "${n/1024} KB"; else -> "${n/(1024*1024)} MB" }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    override fun onDestroy() { executor.shutdownNow(); super.onDestroy() }
}
