# MoonTune Android Organizer — prototype source

This is an **Android Studio prototype project**, not a finished/installable APK. This environment has no Android SDK or Gradle installation, so I could not compile or test an APK here.

## Current prototype scope

- Android Storage Access Framework folder picker, so the user explicitly grants access to a chosen internal-storage or USB folder.
- Recursive scan of common audio extensions.
- Chromaprint/fpcalc dependency and AcoustID lookup flow for fingerprint-based candidate lookup, followed by MusicBrainz recording lookup.
- Manual tag editor using Jaudiotagger for supported formats.
- Writes a tagged *copy* rather than overwriting the original file.

## Not complete yet (important)

- **Automatic language recognition from the audio is not implemented.** The current language field is manual; true audio-language detection requires lyrics/transcription or a separate speech/lyrics language-identification component.
- The fingerprint lookup currently reports candidate matches in status text; it does not yet bind the matched MusicBrainz fields into a review queue for one-tap tag application.
- Full batch tag writing, reliable resume/progress for 10,000+ tracks, duplicate resolution, and safe folder reorganization/move are not implemented yet.
- SAF providers vary. The safe-copy tag writer is a prototype and needs device testing, especially on USB storage.

Do not use this prototype on the only copy of a large music library. Test on a small folder of duplicated files first.

## Build in Android Studio

1. Open this folder in Android Studio.
2. Let Gradle sync and install the Android SDK platform/build tools requested by the project.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Android Studio normally places the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.

## API requirements

- Register an AcoustID application and enter your own application key in the app. Do not rely on temporary example keys.
- MusicBrainz requests must use a meaningful User-Agent and be throttled to no more than one request per second. Large collections can take many hours to identify; unmatched results are expected.

## Data safety

The app scans only the folder selected by the user. Audio is copied to app cache for local fingerprint/tag processing and the fingerprint plus duration is sent to AcoustID for lookup. Metadata lookup queries are sent to MusicBrainz. Full audio is not uploaded by the code in this prototype. Cache files should be deleted after processing; the prototype cleanup path needs additional hardening before production use.
