plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.moontune.organizer"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.moontune.organizer"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("com.github.quicklyric:fpcalc-android:1.0.1")
    implementation("com.github.Adonai:jaudiotagger:2.3.14")
}
